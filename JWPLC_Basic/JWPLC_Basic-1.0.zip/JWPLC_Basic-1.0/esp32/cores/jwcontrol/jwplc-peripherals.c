#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "esp32-hal-gpio.h"

const int I2C_BUS = 0;

const uint8_t NORMAL_GPIO_INPUT = 0x01;
const uint8_t NORMAL_GPIO_OUTPUT = 0x03;

const uint8_t ARRAY_MCP23008[] = {
#if defined(ESP32PLC)
	0x20,
	0x21,
#if defined(ESP32PLC_V3)
	0x23,
#endif // ESP32PLC_V3
#endif // ESP32PLC
};
const size_t NUM_ARRAY_MCP23008 = sizeof(ARRAY_MCP23008) / sizeof(uint8_t);

const uint8_t ARRAY_ADS1015[] = {
#if defined(ESP32PLC)
	0x48, 0x49,
#if (defined(ESP32PLC_42) || defined(ESP32PLC_58) || defined(ESP32PLC_57AAR)) || (defined(ESP32PLC_38R) || defined(ESP32PLC_57R) || defined(ESP32PLC_38AR) || defined(ESP32PLC_53ARR) || defined(ESP32PLC_54ARA) || defined(ESP32PLC_50RRA))
	// Only if the PLC has Zone C
	0x4a,
#endif
#if (defined(ESP32PLC_58) || defined(ESP32PLC_54ARA) || defined(ESP32PLC_50RRA)) || (defined(ESP32PLC_57R) || defined(ESP32PLC_53ARR) || defined(ESP32PLC_57AAR))
	// Only if the PLC has Zone D
	0x4b,
#endif
#endif
};
const size_t NUM_ARRAY_ADS1015 = sizeof(ARRAY_ADS1015) / sizeof(uint8_t);

const uint8_t ARRAY_PCA9685[] = {
#if defined(ESP32PLC)
	0x40,
	0x41,
#endif
};
const size_t NUM_ARRAY_PCA9685 = sizeof(ARRAY_PCA9685) / sizeof(uint8_t);

const uint8_t ARRAY_LTC2309[] = {};
const size_t NUM_ARRAY_LTC2309 = sizeof(ARRAY_LTC2309) / sizeof(uint8_t);

const uint8_t ARRAY_MCP23017[] = {
#if defined(PLC14IOS)
    0x20
#endif
};
const size_t NUM_ARRAY_MCP23017 = sizeof(ARRAY_MCP23017) / sizeof(uint8_t);

#ifdef PLC14IOS
static bool channels_used[16];
typedef enum {
	ch_q0_0 = 0,
	ch_q0_1 = 2,
	ch_q0_2 = 4,
	ch_q0_3 = 6,
	NO_CHANNEL,
	ERR = -1
} q_channel_t;

static q_channel_t return_channel(uint32_t pin) {
	q_channel_t channel;
	switch (pin) {
	case Q0_0:
		channel = ch_q0_0;
		break;
	case Q0_1:
		channel = ch_q0_1;
		break;
	case Q0_2:
		channel = ch_q0_2;
		break;
	case Q0_3:
		channel = ch_q0_3;
		break;
	default:
		channel = NO_CHANNEL;
		break;

	}

	return channel;
}

static uint32_t return_pin(uint8_t channel) {
        uint32_t pin;
	switch (channel) {
	case ch_q0_0:
	        pin = Q0_0;
		break;
	case ch_q0_1:
		pin = Q0_1;
		break;
	case ch_q0_2:
	        pin = Q0_2;
		break;
	case ch_q0_3:
	        pin = Q0_3;
		break;
	default:
	        pin = 255;
		errno = EINVAL;
		break;
	}

	return pin;
}

static int is_channel_initialized(uint32_t pin) {
	q_channel_t ch = return_channel(pin);
        if (ch == ERR) {
	        return -1;
        }

        return channels_used[ch] ? 1 : 0;
}

static int init_pin(uint32_t pin, q_channel_t ch, uint32_t freq) {
	uint32_t new_freq = ledcSetup(ch, freq, 12);
        if (new_freq != freq) return -1;

	ledcAttachPin(pin, ch);

        channels_used[ch] = true;

        return 0;
}

static int deinit_pin(uint32_t pin, q_channel_t ch) {
	ledcDetachPin(pin);

        channels_used[ch] = false;

        return 0;
}
#endif

int normal_gpio_init(void) {
#ifdef PLC14IOS
	memset(channels_used, false, sizeof(channels_used));
#endif
	return 0;
}

int normal_gpio_deinit(void) {
#ifdef PLC14IOS
	for (size_t c = 0; c < sizeof(channels_used) / sizeof(bool); c++) {
		if (channels_used[c]) {
			uint32_t pin = return_pin(c);
                        if (pin == 255 || deinit_pin(pin, c) != 0) {
	                        errno = EFAULT;
	                        return -1;
                        }
		}
        }
#endif
	return 0;
}

extern void ARDUINO_ISR_ATTR __pinMode(uint32_t pin, uint8_t mode);
int normal_gpio_set_pin_mode(uint32_t pin, uint8_t mode) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 1) {
	        deinit_pin(pin, ch);
        }
#endif
	__pinMode(pin, mode);
	return 0;
}

extern void ARDUINO_ISR_ATTR __digitalWrite(uint32_t pin, uint8_t val);
int normal_gpio_write(uint32_t pin, uint8_t value) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 1) {
	        deinit_pin(pin, ch);
        }
#endif
	__digitalWrite(pin, value);
	return 0;
}

int normal_gpio_pwm_frequency(uint32_t pin, uint32_t freq) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 1) {
	        ledcChangeFrequency(ch, freq, 12);
        }
        else {
	        init_pin(pin, ch, freq);
        }

        return 0;
#else
        errno = ENOTSUP;
        return -1;
#endif
}

int normal_gpio_pwm_write(uint32_t pin, uint16_t value) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 0) {
	        init_pin(pin, ch, 500);
        }

	ledcWrite(ch, value);

	return 0;
#else
	errno = ENOTSUP;
        return -1;
#endif
}

extern int ARDUINO_ISR_ATTR __digitalRead(uint32_t pin);
extern uint16_t __analogRead(uint32_t pin);
int normal_gpio_read(uint32_t pin, uint8_t* read) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 1) {
	        deinit_pin(pin, ch);
        }
#endif

#ifdef PLC14IOS
	// If we use 14 IOs we should be able to use, we should be able
	// to use ESP32 ADCs as digital pins
        uint16_t analog_read;
	switch (pin) {
	case 32:
	case 33:
		// Up to ~2.7V
		normal_gpio_analog_read(pin, &analog_read); // Applying correction facto
		*read = analog_read > 3500 ? 1 : 0;
		break;
	case 34:
	case 35:
		// Up to ~3.3V
		normal_gpio_analog_read(pin, &analog_read);
		*read = analog_read > 1200 ? 1 : 0;
		break;
	default:
		*read = __digitalRead(pin);
		break;
	}
#else
	*read = __digitalRead(pin);
#endif

	return 0;
}

int normal_gpio_analog_read(uint32_t pin, uint16_t* read) {
#ifdef PLC14IOS
	q_channel_t ch = return_channel(pin);
	int is_channel_used = is_channel_initialized(pin);
        if (is_channel_used < 0) {
	        return is_channel_used;
        }

        if (is_channel_used == 1) {
	        deinit_pin(pin, ch);
        }
#endif
	uint16_t sample = __analogRead(pin);

/*
 * The analog IOs of the ESP32 aren't able to read the full range of values.
 * Based off our tests, the analog inputs at 10V read as 2992 to 2957, which is around 11.5 bits of precision.
 * To use all the 12 bits of precision, we'll have to scale it up later.
 * Voltages below 0.5V aren't detected. Calculating a regression line we can tell
 * the values have an offset of aproximately -171.
 * Combining both values we can add SAMPLE + 171 and scale the value to obtain the maximum range.
 * The scaling factor is obtained with the following: 4096/(2992+171) = ~ 1.2950
 *
 * The final operation would be (SAMPLE + 171)* 1.2950
 * This value correction is performed by the function:
 *      correctionFactor(int sample,float correction_factor)
 * Limitation: Values below 0.5V still won't be detected correctly.
 * There will be an abrupt jump between 0 and 222.
 *
 */
#if defined(PLC14IOS)
	const float CORRECTION_FACTOR = (4096.0/(2992+171));
	if (sample > 0) sample += 171;
        sample = (sample * CORRECTION_FACTOR);
        if (sample > 4095) {
	        sample = 4095;
        }
#endif

        *read = sample;
	return 0;
}
