void my_log(const char *msg);
