#ifndef __INDUSTRIALSHIELDS_H__
#define __INDUSTRIALSHIELDS_H__

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

	int IS_initDefaultIOPins(void);

#ifdef __cplusplus
}
#endif

#endif // __INDUSTRIALSHIELDS_H
