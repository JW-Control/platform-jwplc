#ifndef __ESP32_PERIPHERALS_H__
#define __ESP32_PERIPHERALS_H__

#include "plc-peripherals/include/plc-peripherals.h"

#endif // __ESP32_PERIPHERALS_H__
