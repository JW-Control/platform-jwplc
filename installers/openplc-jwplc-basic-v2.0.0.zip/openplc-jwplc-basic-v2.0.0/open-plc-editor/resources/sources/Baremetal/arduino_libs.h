//disable pins
//uint16_t disabled_pins[11] = {1, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255}; //10 pins max. First array position is used as index
extern uint16_t pinMask_DIN[];
extern uint16_t pinMask_AIN[];
extern uint16_t pinMask_DOUT[];
extern uint16_t pinMask_AOUT[];

#ifdef SIMULATOR_MODE
    // Simulator: no-op stubs for all hardware modules (no platform headers needed)
    #include "modules/simulator_stubs.c"
#else
    #ifdef USE_DS18B20_BLOCK
        #include "modules/ds18b20.c"
    #endif

    #ifdef USE_P1AM_BLOCKS
        #include "modules/p1am.c"
    #endif

    #ifdef USE_CLOUD_BLOCKS
        #include "modules/arduino_cloud.c"
    #endif

    #ifdef USE_MQTT_BLOCKS
        #include "modules/mqtt.c"
    #endif

    #ifdef USE_SM_BLOCKS
        #include "modules/sm_cards.c"
    #endif

    #ifdef USE_ARDUINOCAN_BLOCK
        #include "modules/arduinocan.c"
    #endif

    #ifdef USE_STM32CAN_BLOCK
        #include "modules/stm32can.c"
    #endif
#endif
