#ifndef __JWCONTROL_H__
#define __JWCONTROL_H__

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

	int IS_initDefaultIOPins(void);

#ifdef __cplusplus
}
#endif

#endif // __JWCONTROL_H__
