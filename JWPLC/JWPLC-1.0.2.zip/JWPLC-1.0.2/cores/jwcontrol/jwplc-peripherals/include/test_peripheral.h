#ifndef TEST_PERIPHERAL_H
#define TEST_PERIPHERAL_H

#ifdef __cplusplus
extern "C" {
#endif

// Función de prueba para verificar la inclusión
void test_peripheral_print(void);

#ifdef __cplusplus
}
#endif

#endif // TEST_PERIPHERAL_H