 #ifndef __JWPLC_PERIPHERALS_H__
 #define __JWPLC_PERIPHERALS_H__
 
 #include "detect-platform.h"
 
 #include "WireC.h"
 #include "peripheral-tca6424a.h"
 #include "expanded-gpio.h"
 
 #endif // __JWPLC_PERIPHERALS_H__