#include <Arduino.h>
#include "test_peripheral.h"

void test_peripheral_print(void) {
    Serial.println("¡El módulo de periféricos se incluyó y compiló correctamente!");
}