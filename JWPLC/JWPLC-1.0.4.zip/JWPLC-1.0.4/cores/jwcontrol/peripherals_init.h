#ifndef PERIPHERALS_INIT_H
#define PERIPHERALS_INIT_H

#ifdef __cplusplus
extern "C" {
#endif

void initPeripherals(void);

#ifdef __cplusplus
}
#endif

#endif // PERIPHERALS_INIT_H